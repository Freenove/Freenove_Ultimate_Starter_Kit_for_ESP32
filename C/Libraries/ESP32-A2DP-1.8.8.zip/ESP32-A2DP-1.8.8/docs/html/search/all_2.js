var searchData=
[
  ['callback_0',['Sending Data from a A2DS Data Source with a Callback',['../index.html#autotoc_md13',1,'']]],
  ['callbacks_1',['Accessing the Sink Data Stream with Callbacks',['../index.html#autotoc_md8',1,'']]],
  ['change_20history_2',['Change History',['../index.html#autotoc_md21',1,'']]],
  ['clip_3',['clip',['../class_a2_d_p_volume_control.html#a23700514ed3bb33151ea90033e8dcbea',1,'A2DPVolumeControl']]],
  ['commands_4',['Support for AVRC Commands',['../index.html#autotoc_md11',1,'']]]
];
