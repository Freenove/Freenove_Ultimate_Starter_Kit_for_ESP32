var searchData=
[
  ['get_5fvolume_5ffactor_0',['get_volume_factor',['../class_a2_d_p_volume_control.html#a6af31a3ffaad03ffa06930bbb3d3d285',1,'A2DPVolumeControl']]],
  ['get_5fvolume_5ffactor_5fmax_1',['get_volume_factor_max',['../class_a2_d_p_volume_control.html#ae5ff3aa2b2b615e7eb01c8a8f164ef60',1,'A2DPVolumeControl']]]
];
