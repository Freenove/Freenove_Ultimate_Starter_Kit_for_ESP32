var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstuvw",
  1: "ab",
  2: "b",
  3: "acgsu",
  4: "eimv",
  5: "e",
  6: "e",
  7: "e",
  8: "ae",
  9: "abefmrst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Modules",
  9: "Pages"
};

