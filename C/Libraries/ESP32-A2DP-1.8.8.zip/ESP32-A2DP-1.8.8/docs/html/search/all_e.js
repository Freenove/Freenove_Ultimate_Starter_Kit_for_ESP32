var searchData=
[
  ['receiver_0',['A2DP Sink (Music Receiver)',['../index.html#autotoc_md3',1,'']]],
  ['receiver_20and_20sender_20for_20the_20esp32_1',['A Simple Arduino Bluetooth Music Receiver and Sender for the ESP32',['../index.html',1,'']]]
];
