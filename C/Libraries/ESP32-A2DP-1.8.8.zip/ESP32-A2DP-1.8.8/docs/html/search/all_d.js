var searchData=
[
  ['pins_0',['pins',['../index.html#autotoc_md4',1,'A Simple I2S Example (A2DS Sink) using default Pins'],['../index.html#autotoc_md5',1,'Defining Pins']]],
  ['processing_1',['Digital Sound Processing',['../index.html#autotoc_md16',1,'']]],
  ['protocols_2',['Supported Bluetooth Protocols',['../index.html#autotoc_md1',1,'']]]
];
