var searchData=
[
  ['logging_0',['Logging',['../index.html#autotoc_md14',1,'']]]
];
