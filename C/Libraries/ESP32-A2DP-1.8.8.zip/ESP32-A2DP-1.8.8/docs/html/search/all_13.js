var searchData=
[
  ['with_20a_20callback_0',['Sending Data from a A2DS Data Source with a Callback',['../index.html#autotoc_md13',1,'']]],
  ['with_20callbacks_1',['Accessing the Sink Data Stream with Callbacks',['../index.html#autotoc_md8',1,'']]]
];
