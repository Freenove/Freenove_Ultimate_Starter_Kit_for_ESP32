var searchData=
[
  ['esp_5favrc_5frn_5fplay_5fstatus_5fchange_0',['ESP_AVRC_RN_PLAY_STATUS_CHANGE',['../group__a2dp.html#gab981cf845089ef19df871466126b6f14',1,'external_lists.h']]]
];
