var searchData=
[
  ['clip_0',['clip',['../class_a2_d_p_volume_control.html#a23700514ed3bb33151ea90033e8dcbea',1,'A2DPVolumeControl']]]
];
